﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Vehicles.Core.IO.Interfaces;

namespace Vehicles.Core.IO
{
    public class ConsnoleWriter : IWriter
    {
        public void WriteLine(string str) => Console.WriteLine(str);
    }
}
