﻿using Vehicles.Core;
using Vehicles.Core.IO;
using Vehicles.Core.IO.Interfaces;
using Vehicles.Factories;
using Vehicles.Factories.Interfaces;

namespace Vehicles
{
    internal class Program
    {
        static void Main(string[] args)
        {
            IReader reader = new ConsoleReader();
            IWriter writer = new ConsnoleWriter();
            IVehicleFactories factory = new VehicleFactory();

            Engine engine = new Engine(reader, writer, factory);
            engine.Run();
        }
    }
}